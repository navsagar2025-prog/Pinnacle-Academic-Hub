export const COURSES = [
  {
    id: "jee",
    title: "JEE Main & Advanced",
    icon: "🔬",
    description:
      "Comprehensive preparation for India's most prestigious engineering entrance exam. Expert coverage of Physics, Chemistry, and Mathematics from foundational to advanced levels.",
    duration: "1–2 years",
    batches: ["Morning", "Evening"],
    seats: 30,
    fee: 48000,
    color: "navy",
    highlights: ["500+ hours of teaching", "Weekly mock tests", "Doubt clearing sessions", "Study material included"],
    eligibility: "Class 11 or 12 pass/appearing",
  },
  {
    id: "neet",
    title: "NEET UG",
    icon: "🧬",
    description:
      "Targeted NEET coaching with deep subject coverage in Physics, Chemistry, and Biology. Our biology program alone covers NCERT at mastery level.",
    duration: "1–2 years",
    batches: ["Morning", "Evening"],
    seats: 30,
    fee: 48000,
    color: "teal",
    highlights: ["NCERT-focused biology", "1000+ practice questions", "AIIMS-level mock tests", "Revision modules"],
    eligibility: "Class 11 or 12 pass/appearing",
  },
  {
    id: "class12",
    title: "Class 11 & 12 Board",
    icon: "📚",
    description:
      "CBSE and UP Board excellence program for PCM and PCB streams. Full syllabus coverage aligned with board exam patterns.",
    duration: "2 years (or 1 year for Class 12)",
    batches: ["Morning", "Afternoon", "Evening"],
    seats: 35,
    fee: 36000,
    color: "maroon",
    highlights: ["Board-pattern test series", "Previous year papers", "Practical guidance", "Parent progress reports"],
    eligibility: "Class 10 pass/appearing",
  },
  {
    id: "class10",
    title: "Class 9 & 10",
    icon: "✏️",
    description:
      "Strong foundation program for Class 9 & 10 students in Science and Mathematics. Builds analytical thinking for future competitive exams.",
    duration: "2 years (or 1 year for Class 10)",
    batches: ["Afternoon", "Evening"],
    seats: 40,
    fee: 28000,
    color: "gold",
    highlights: ["Concept-first teaching", "Activity-based learning", "Monthly tests", "School syllabus coverage"],
    eligibility: "Class 8 pass/appearing",
  },
  {
    id: "foundation",
    title: "Foundation (Grade 6–8)",
    icon: "🌱",
    description:
      "Early excellence program for middle school students. Builds the mathematical and scientific thinking required for future JEE/NEET success.",
    duration: "3 years",
    batches: ["Afternoon"],
    seats: 40,
    fee: 20000,
    color: "teal",
    highlights: ["OLYMPIAD preparation", "Mental maths techniques", "Science projects", "Personality development"],
    eligibility: "Class 5 pass/appearing",
  },
];

export const FACULTY = [
  {
    name: "Dr. Ramesh Kumar",
    designation: "Head of Physics",
    qualification: "Ph.D. Physics, IIT Delhi · M.Sc. Physics, University of Delhi",
    experience: "14 years",
    teaches: "JEE Advanced Physics · NEET Physics",
    achievement: "Author of 2 Physics reference books; produced 50+ IIT selections",
    image: null,
    initials: "RK",
  },
  {
    name: "Ms. Priya Sharma",
    designation: "Senior Chemistry Faculty",
    qualification: "M.Sc. Chemistry, NIT Allahabad · B.Ed.",
    experience: "10 years",
    teaches: "JEE Chemistry · NEET Chemistry · Class 12 Board",
    achievement: "Specializes in organic chemistry problem-solving; 97% board-pass rate",
    image: null,
    initials: "PS",
  },
  {
    name: "Mr. Ajay Tiwari",
    designation: "Mathematics Faculty",
    qualification: "M.Sc. Mathematics, BHU · CSIR-NET qualified",
    experience: "8 years",
    teaches: "JEE Mathematics · Class 11-12 Mathematics",
    achievement: "Pioneered shortcut techniques adopted across 5 Noida coaching institutes",
    image: null,
    initials: "AT",
  },
  {
    name: "Ms. Nidhi Verma",
    designation: "Biology Faculty",
    qualification: "M.Sc. Zoology, AMU · B.Ed.",
    experience: "9 years",
    teaches: "NEET Biology · Class 11-12 Biology",
    achievement: "200+ NEET selections in 5 years; NCERT deep-reading specialist",
    image: null,
    initials: "NV",
  },
  {
    name: "Mr. Sanjay Gupta",
    designation: "Physics Faculty",
    qualification: "M.Sc. Physics, HNBGU · GATE qualified",
    experience: "7 years",
    teaches: "JEE Physics · NEET Physics · Class 12 Board",
    achievement: "Expert in mechanics and electrodynamics; JEE Advanced numericals trainer",
    image: null,
    initials: "SG",
  },
  {
    name: "Ms. Anita Gupta",
    designation: "Foundation & Class 9-10",
    qualification: "M.Sc. Mathematics, Lucknow University · B.Ed.",
    experience: "11 years",
    teaches: "Class 9-10 Mathematics & Science · Foundation Programme",
    achievement: "100% pass rate for Class 10 board students; Olympiad champion trainer",
    image: null,
    initials: "AG",
  },
];

// Real topper data sourced from Pinnacle Academic Classes JustDial gallery achievement banners.
// CBSE Class XII Commerce 2020 results + subject pass-rate banners.
export const TOPPERS = [
  {
    name: "Pragalva Mishra",
    exam: "CBSE Class XII Commerce 2020",
    rank: "95%",
    college: "Accountancy — School Topper",
    batch: "CBSE Commerce — Class XII",
    quote: "Pinnacle's structured approach to Accountancy made every concept crystal clear.",
    initials: "PM",
  },
  {
    name: "Ramya",
    exam: "CBSE Class XII Commerce 2020",
    rank: "97%",
    college: "Economics — School Topper",
    batch: "CBSE Commerce — Class XII",
    quote: "The faculty's depth in Economics and consistent mock tests gave me the edge.",
    initials: "R",
  },
  {
    name: "Anjali Gupta",
    exam: "CBSE Class XII Commerce 2020",
    rank: "94%",
    college: "Accountancy — 2nd Rank",
    batch: "CBSE Commerce — Class XII",
    quote: "Every doubt was addressed immediately. That made all the difference.",
    initials: "AG",
  },
  {
    name: "Saiyam Dhamija",
    exam: "CBSE Class XII Commerce 2020",
    rank: "91%",
    college: "Economics — 2nd Rank",
    batch: "CBSE Commerce — Class XII",
    quote: "The revision sessions at Pinnacle turned my weak subjects into my strongest.",
    initials: "SD",
  },
  {
    name: "Ramya",
    exam: "CBSE Class XII Commerce 2020",
    rank: "91%",
    college: "Accountancy — 3rd Rank",
    batch: "CBSE Commerce — Class XII",
    quote: "Consistent practice and expert guidance helped me score across all subjects.",
    initials: "R",
  },
  {
    name: "Pragalva Mishra",
    exam: "CBSE Class XII Commerce 2020",
    rank: "90%",
    college: "Economics & BST — Topper",
    batch: "CBSE Commerce — Class XII",
    quote: "Pinnacle helped me top multiple subjects through their focused coaching.",
    initials: "PM",
  },
];

// Subject pass-rate highlights sourced from Pinnacle JustDial gallery achievement banner.
export const BOARD_PASS_RATES = [
  { subject: "Maths", rate: "100%", icon: "📐" },
  { subject: "Science", rate: "100%", icon: "🔬" },
  { subject: "SST", rate: "96%", icon: "🌍" },
];

export const TESTIMONIALS = [
  {
    name: "Rakesh Sharma",
    role: "Parent of Aditya Sharma (IIT Bombay)",
    text: "Pinnacle transformed my son's life. The personal attention from faculty, regular parent-teacher meetings, and the structured study program gave us confidence from day one. I highly recommend Pinnacle to every parent in Greater Noida.",
    initials: "RS",
    rating: 5,
  },
  {
    name: "Kavita Patel",
    role: "Parent of Sneha Patel (AIIMS Delhi)",
    text: "When Sneha joined Pinnacle, she was struggling with organic chemistry. Within 6 months, she topped her batch. The faculty's dedication is unmatched. They really care about each student's success.",
    initials: "KP",
    rating: 5,
  },
  {
    name: "Vikram Mishra",
    role: "Parent of Rohan Mishra (NIT Trichy)",
    text: "The study material quality, the mock test pattern, and the doubt-clearing system at Pinnacle are world-class. Rohan's percentile jumped from 88 to 99.4 in one year. That says everything.",
    initials: "VM",
    rating: 5,
  },
  {
    name: "Sunita Verma",
    role: "Parent of Shivam Verma (JEE 2023 — NIT Delhi)",
    text: "I was worried about Shivam's consistency, but Pinnacle's weekly tests and progress tracking kept him motivated throughout the year. The transparency about performance is what sets Pinnacle apart.",
    initials: "SV",
    rating: 5,
  },
];

export const STATS = [
  { value: "2,000+", label: "Students Trained", icon: "👨‍🎓" },
  { value: "85+", label: "IIT/AIIMS Selections", icon: "🏆" },
  { value: "320+", label: "NIT/State Medical Selections", icon: "🎓" },
  { value: "100%", label: "Maths Pass Rate", icon: "📐" },
  { value: "14+", label: "Years of Excellence", icon: "⭐" },
  { value: "96%+", label: "Board Exam Pass Rate", icon: "📊" },
];

export const NOTICES = [
  {
    id: 1,
    date: "2026-04-28",
    title: "JEE Advanced Mock Test — 5 May 2026",
    body: "All JEE 2026 batch students must report by 9:00 AM on 5 May for the full-length mock test. Admit cards available at the front desk.",
    category: "Test",
  },
  {
    id: 2,
    date: "2026-04-25",
    title: "Fee Payment Reminder — April Installment Due",
    body: "Kindly note that the April fee installment is due by 30 April 2026. Please submit payment at the accounts office or via bank transfer.",
    category: "Fee",
  },
  {
    id: 3,
    date: "2026-04-22",
    title: "Summer Batch Admissions Open — NEET 2027",
    body: "Applications are now open for the NEET 2027 evening batch starting 1 June 2026. Limited seats available. Early registration fee waiver for applications before 15 May.",
    category: "Admissions",
  },
  {
    id: 4,
    date: "2026-04-18",
    title: "Parent-Teacher Meeting — 4 May 2026",
    body: "Monthly PTM will be held on 4 May 2026 (Sunday) from 10:00 AM to 1:00 PM. Attendance is requested from all enrolled students' parents.",
    category: "Event",
  },
  {
    id: 5,
    date: "2026-04-10",
    title: "New Study Material — Organic Chemistry Chapter 6",
    body: "Updated Organic Chemistry study notes (Chapter 6: Aldehydes & Ketones) are now available for NEET students at the front office.",
    category: "Academic",
  },
];

export const FAQ = [
  {
    q: "What courses does Pinnacle offer?",
    a: "Pinnacle offers JEE Main & Advanced, NEET UG, Class 11–12 board, Class 9–10, and Foundation (Grade 6–8) programmes with morning and evening batches.",
  },
  {
    q: "How do I enrol my child?",
    a: "Visit us at Shop Mart, Gaur City 2, Sec. 16C, Greater Noida (PIN 201009), or fill the online enquiry form. A counsellor will contact you within 24 hours to guide you through batch selection and the admission process.",
  },
  {
    q: "Is there a demo class available?",
    a: "Yes! We offer a free demo class for every prospective student. Book through our website or call us to schedule your preferred subject and timing.",
  },
  {
    q: "How are progress reports shared with parents?",
    a: "We conduct monthly Parent-Teacher Meetings and share progress reports after every test. The parent portal (accessed through this website) gives real-time visibility into fee status, timetable, and notices.",
  },
  {
    q: "What is the fee structure?",
    a: "Fees vary by programme and batch. JEE/NEET programmes are ₹48,000/year; Class 11–12 is ₹36,000/year; Class 9–10 is ₹28,000/year; Foundation is ₹20,000/year. Instalment options available. Visit our Admissions page for details.",
  },
  {
    q: "Do you provide study material?",
    a: "Yes, comprehensive printed study material prepared by our faculty is included in the fee for all programmes. Additional practice booklets and previous year papers are also available.",
  },
  {
    q: "Are there any scholarships or fee concessions?",
    a: "We offer merit scholarships for students scoring above 90% in their previous board exam or previous institute performance. Sibling discounts and SC/ST concessions are also available.",
  },
  {
    q: "Can parents track their child's attendance and performance?",
    a: "Yes. Parents receive login credentials to the Parent Portal on this website, where they can view timetable, notices, fee records, and academic progress.",
  },
];
